#!/bin/bash
mkdir -p node_modules
npm i